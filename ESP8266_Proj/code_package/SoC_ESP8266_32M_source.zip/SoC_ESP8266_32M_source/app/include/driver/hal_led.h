#ifndef _HAL_RGB_LED_H
#define _HAL_RGB_LED_H

#include <stdio.h>
#include <c_types.h>
#include <gpio.h>
#include <eagle_soc.h>

/* Define your drive pin, when the io is low, the led will be lighted! */
#define GPIO_RGB_R	15
#define GPIO_RGB_G	12
#define GPIO_RGB_B	13

/* Set GPIO Direction */
#define RedOn()			GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_RGB_R), 1)
#define RedOff()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_RGB_R), 0)

#define GreenOn()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_RGB_G), 1)
#define GreenOff()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_RGB_G), 0)

#define BlueOn()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_RGB_B), 1)
#define BlueOff()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_RGB_B), 0)

/* Function declaration */
void rgbGpioInit(void);

#endif
