#ifndef _HAL_IR_H
#define _HAL_IR_H

#include <stdio.h>
#include <c_types.h>
#include <gpio.h>
#include <eagle_soc.h>

// Define your drive pin, 
#define GPIO_IR		14

/* Set GPIO Direction */
#define IR_HIGH()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_IR), 1)
#define IR_LOW()		GPIO_OUTPUT_SET(GPIO_ID_PIN(GPIO_IR), 0)

typedef enum{
	AutoMode = 0x0,//自动
	CoolMode = 0x1,//制冷
	WetMode  = 0x2,//加湿
	WindMode = 0x3,//送风
	HeatMode = 0x4//制热
} ModeDef;

typedef enum {
	Off = 0x0,
	On  = 0x1
} SwitchDef;

typedef enum {
	AutoSpeed   = 0x0,
	FirstSpeed  = 0x1,
	SecondSpeed = 0x2,
	ThirdSpeed  = 0x3,
} WindSpeedDef;


/* Function declaration */
void IR_GpioInit(void);
void IR_SendCommand(void);
void IR_ChangeCommand(SwitchDef s, ModeDef mode, unsigned char t);
void IR_Checkout(void);
void IR_Temperature(unsigned char t);
void IR_TurnOnOff(SwitchDef s);
void IR_ChangeMode(ModeDef mode);
void ICACHE_FLASH_ATTR delay_ms(uint16_t ms);

#endif
