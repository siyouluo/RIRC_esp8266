/***********************************************
 * @file	hal_led.c
 * @author	Luo Siyou
 * @version	V1.0
 * @date	2019-07-26
 *
 * @brief	driver a gpio pin to simulate infrared protocol in order to control the airconditioner
 *
***********************************************/

#include "driver/hal_led.h"
#include "osapi.h"

void ICACHE_FLASH_ATTR rgbGpioInit(void)
{
	/* Migrate your driver code */
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTDO_U, FUNC_GPIO15);
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTDI_U, FUNC_GPIO12);
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTCK_U, FUNC_GPIO13);

	gpio_output_set(0, 0, GPIO_ID_PIN(GPIO_RGB_R) |  GPIO_ID_PIN(GPIO_RGB_G) |  GPIO_ID_PIN(GPIO_RGB_B), 0);
	os_printf("rgbGpioInit \r\n");
	
	RedOff();
	GreenOff();
	BlueOff();
}
