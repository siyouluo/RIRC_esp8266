/**********************************************
 * @file	hal_ir.c
 * @author	Luo Siyou
 * @version	V1.0
 * @date	2019-07-27
 *
 * @brief	
 *
***********************************************/
// os_delay_us(100)
#include "driver/hal_ir.h"
#include "driver/hal_led.h"
#include "osapi.h"

unsigned char IR_CodeBuf[68]={\
0,1,0,0,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,1,0,\
1,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1};


//模式0~模式4
void IR_ChangeMode(ModeDef mode)
{
	switch(mode)
	{
	case AutoMode:	IR_CodeBuf[1]=0;IR_CodeBuf[2]=0;IR_CodeBuf[3]=0;break;//自动
	case CoolMode:	IR_CodeBuf[1]=1;IR_CodeBuf[2]=0;IR_CodeBuf[3]=0;break;//制冷
	case WetMode:	IR_CodeBuf[1]=0;IR_CodeBuf[2]=1;IR_CodeBuf[3]=0;break;//加湿
	case WindMode:	IR_CodeBuf[1]=1;IR_CodeBuf[2]=1;IR_CodeBuf[3]=0;break;//送风
	case HeatMode:	IR_CodeBuf[1]=0;IR_CodeBuf[2]=0;IR_CodeBuf[3]=1;break;//制热
	default: 	IR_CodeBuf[1]=0;IR_CodeBuf[2]=0;IR_CodeBuf[3]=0;//默认：自动
	}
	IR_Checkout();
	IR_SendCommand();
}
void IR_TurnOnOff(SwitchDef s)
{
	switch(s)
	{
		case Off: IR_CodeBuf[4]=0;break;
		case On:  IR_CodeBuf[4]=1;break;
		default:  IR_CodeBuf[4]=0;
	}
	IR_Checkout();
	IR_SendCommand();
}
//调温，16~30度
//将(t-16)转换成2进制，IR_CodeBuf[9]为LSB，IR_CodeBuf[12]为MSB
void IR_Temperature(unsigned char t)
{
	unsigned char t1;
	t1 = t-16;
	IR_CodeBuf[9]=(t1)&1;
	IR_CodeBuf[10]=((t1)>>1)&1;
	IR_CodeBuf[11]=((t1)>>2)&1;
	IR_CodeBuf[12]=((t1)>>3)&1;
	IR_Checkout();
	IR_SendCommand();
}
//校验码
void IR_Checkout()
{
	unsigned char check;
	check=IR_CodeBuf[1] + IR_CodeBuf[2]*2 + IR_CodeBuf[3]*4+IR_CodeBuf[4]*8;
	check+=IR_CodeBuf[9] + IR_CodeBuf[10]*2 + IR_CodeBuf[11]*4 + IR_CodeBuf[12]*8;	
	check+=IR_CodeBuf[25];
	check+=IR_CodeBuf[40];
	check+=IR_CodeBuf[62];
	check+=12;
	check&=0x0f;

	IR_CodeBuf[64]=check&1;
	IR_CodeBuf[65]=(check>>1)&1;
	IR_CodeBuf[66]=(check>>2)&1;
	IR_CodeBuf[67]=(check>>3)&1;
}
//更改红外数据时仅更改开关，制冷或制热模式，以及温度，其余保持默认值不变
//s：开：1，关：0
//mode：
//t：	26~30
void IR_ChangeCommand(SwitchDef s, ModeDef mode, unsigned char t)
{
	IR_TurnOnOff(s);
	IR_ChangeMode(mode);
	IR_Temperature(t);
	IR_Checkout();
	IR_SendCommand();
}
void ICACHE_FLASH_ATTR IR_GpioInit(void)
{
	/* Migrate your driver code */
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTMS_U, FUNC_GPIO14);

	gpio_output_set(0, 0, GPIO_ID_PIN(GPIO_IR), 0);
	os_printf("IR_GpioInit \r\n");
	IR_LOW();
	IR_Temperature(23);
	IR_TurnOnOff(Off);
	IR_ChangeMode(AutoMode);
	IR_Checkout();
}
//发送红外数据
//依次发送：起始码+35位数据码+连接码+32位数据码
void ICACHE_FLASH_ATTR IR_SendCommand(void)
{
	unsigned char i;

	//起始码
	IR_HIGH();delay_ms(9);//emit 9ms
	IR_LOW();delay_ms(4);os_delay_us(500);//delay 4.5ms
	//35位数据码
	for(i = 1; i < 36; i++)
	{		
		IR_HIGH();os_delay_us(560);//emit 0.56ms
		if (IR_CodeBuf[i])
		{IR_LOW();delay_ms(1);os_delay_us(600);}//delay 1.685ms
		else
		{IR_LOW();os_delay_us(560);}//delay 0.56ms	
	}
	//连接码
	IR_HIGH();os_delay_us(560);//emit 0.56ms
	IR_LOW();delay_ms(20);
	//32位数据码
	for(i = 36; i < 68; i++)
	{		
		IR_HIGH();os_delay_us(560);//emit 0.56ms
		if (IR_CodeBuf[i])
		{IR_LOW();delay_ms(1);os_delay_us(600);}//delay 1.685ms
		else
		{IR_LOW();os_delay_us(560);}//delay 0.56ms	
	}
	IR_HIGH();os_delay_us(560);//emit 0.56ms
	IR_LOW();
}
void ICACHE_FLASH_ATTR delay_ms(uint16_t ms)
{
	uint16_t i;
	for(i=ms;i>0;i--)
	{
		system_soft_wdt_feed();//feed the dog
		os_delay_us(1000);
	}	
}
